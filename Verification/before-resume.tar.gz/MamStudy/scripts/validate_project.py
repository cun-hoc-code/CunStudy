#!/usr/bin/env python3
"""Structural checks only. This does NOT replace an iOS compile or device tests."""
import json
import plistlib
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
for path in sorted(root.glob("Config/*")):
    with path.open("rb") as stream:
        plistlib.load(stream)
with (root / "Resources/PrivacyInfo.xcprivacy").open("rb") as stream:
    plistlib.load(stream)
for contents in root.glob("Resources/**/*.json"):
    data = json.loads(contents.read_text())
    for icon in data.get("images", []):
        if "filename" in icon:
            assert (contents.parent / icon["filename"]).is_file(), icon
required = ["App/MamStudyApp.swift", "App/ReminderService.swift", "Widget/MamWidgets.swift", "Package.swift", ".github/workflows/build-ios.yml"]
for name in required:
    assert (root / name).is_file(), name
app_plist = plistlib.loads((root / "Config/App-Info.plist").read_bytes())
assert app_plist["NSAlarmKitUsageDescription"]
assert app_plist["StudyAppGroup"] == "$(STUDY_APP_GROUP)"
widget_plist = plistlib.loads((root / "Config/Widget-Info.plist").read_bytes())
assert widget_plist["StudyAppGroup"] == app_plist["StudyAppGroup"]
print("PASS: plist, privacy manifest, icon references, required files, widget group wiring")
print("Run swift test for core behavior and scripts/build-ios.sh on macOS for iOS compile.")
