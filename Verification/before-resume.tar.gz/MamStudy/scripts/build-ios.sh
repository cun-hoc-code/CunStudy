#!/bin/bash
set -euo pipefail

scheme="${1:-MamStudy}"
case "$scheme" in MamStudy|MamStudyBasic) ;; *) echo "Unknown scheme: $scheme" >&2; exit 2;; esac
if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "This script needs macOS with Xcode 26+. On Arch/Windows, use GitHub Actions." >&2
  exit 2
fi
major=$(xcodebuild -version | awk '/Xcode / {split($2, a, "."); print a[1]}')
if [ "$major" -lt 26 ]; then
  echo "Xcode 26+ is required to compile AlarmKit. Select an Xcode 26 installation first." >&2
  exit 2
fi
mkdir -p "build/$scheme/logs" "build/$scheme/output/Payload"
swift test 2>&1 | tee "build/$scheme/logs/core-tests.log"
xcodegen generate --spec project.yml
xcodebuild -project MamStudy.xcodeproj -scheme "$scheme" -configuration Release \
  -destination 'generic/platform=iOS' -sdk iphoneos -derivedDataPath "build/$scheme/DerivedData" \
  -resultBundlePath "build/$scheme/result-$(date +%Y%m%d%H%M%S).xcresult" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" \
  build 2>&1 | tee "build/$scheme/logs/xcodebuild.log"
app_path="build/$scheme/DerivedData/Build/Products/Release-iphoneos/MamStudy.app"
test -d "$app_path"
test -s "$app_path/MamStudy"
file "$app_path/MamStudy" | tee "build/$scheme/logs/binary.txt"
file "$app_path/MamStudy" | grep -q 'Mach-O'
if [ "$scheme" = "MamStudy" ]; then
  test -s "$app_path/PlugIns/MamStudyWidgets.appex/MamStudyWidgets"
fi
ditto "$app_path" "build/$scheme/output/Payload/MamStudy.app"
(cd "build/$scheme/output" && zip -qry "../$scheme-unsigned.ipa" Payload)
unzip -t "build/$scheme/$scheme-unsigned.ipa"
shasum -a 256 "build/$scheme/$scheme-unsigned.ipa" > "build/$scheme/SHA256SUMS.txt"
echo "Created build/$scheme/$scheme-unsigned.ipa (unsigned; re-sign before installing)."
