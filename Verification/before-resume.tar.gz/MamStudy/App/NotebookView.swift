import SwiftUI

struct NotebookView: View {
    @EnvironmentObject private var store: AppStore
    @State private var draft: QuickNote?
    @State private var category: NoteCategory? = nil
    @State private var search = ""
    var body: some View {
        NavigationStack {
            PaperPage {
                Picker("Phân loại", selection: $category) {
                    Text("Tất cả").tag(NoteCategory?.none)
                    ForEach(NoteCategory.allCases) { Text($0.title).tag(Optional($0)) }
                }
                let items = store.state.notes.filter {
                    (category == nil || $0.category == category) && (search.isEmpty || "\($0.title) \($0.body)".localizedCaseInsensitiveContains(search))
                }.sorted { $0.pinned != $1.pinned ? $0.pinned : $0.updatedAt > $1.updatedAt }
                if items.isEmpty { EmptyPageCard(symbol: "pencil.and.scribble", title: "Nghĩ đến đâu, ghi đến đó", detail: "Một cuốn sách cần mua, một ý hay trên lớp, một điều bạn không muốn quên.") }
                ForEach(items) { note in
                    Button { draft = note } label: {
                        PaperCard(color: note.color) {
                            VStack(alignment: .leading, spacing: 9) {
                                HStack { Text(note.category.title.uppercased()).font(.caption2.bold()); Spacer(); if note.pinned { Image(systemName: "pin.fill") } }
                                Text(note.title).font(.system(.title3, design: .rounded, weight: .semibold))
                                Text(note.body).lineLimit(6).font(.body)
                                Text(note.updatedAt, format: .dateTime.day().month()).font(.caption).foregroundStyle(.secondary)
                            }
                        }
                    }.buttonStyle(.plain)
                }
            }
            .navigationTitle("Sổ tay")
            .searchable(text: $search, prompt: "Tìm ghi chú…")
            .toolbar { Button { var note = QuickNote(); note.category = category ?? .quick; draft = note } label: { Image(systemName: "square.and.pencil") }.accessibilityLabel("Ghi nhanh") }
            .sheet(item: $draft) { NoteEditor(value: $0) }
        }
    }
}
