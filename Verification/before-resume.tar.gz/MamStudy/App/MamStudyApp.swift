import SwiftUI
import UserNotifications

final class ForegroundNotifications: NSObject, UNUserNotificationCenterDelegate {
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification,
        withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound])
    }
}

@main
struct MamStudyApp: App {
    @StateObject private var store = AppStore()
    @Environment(\.scenePhase) private var scenePhase
    private let notifications = ForegroundNotifications()
    init() { UNUserNotificationCenter.current().delegate = notifications }
    var body: some Scene {
        WindowGroup {
            RootView().environmentObject(store).environmentObject(store.reminders)
                .tint(Pencil.green).foregroundStyle(Pencil.ink)
                .preferredColorScheme(.light)
                .environment(\.locale, Locale(identifier: "vi_VN"))
                .onChange(of: scenePhase) { _, phase in if phase == .active { store.refresh() } }
                .onReceive(NotificationCenter.default.publisher(for: UIApplication.significantTimeChangeNotification)) { _ in store.refresh() }
                .onOpenURL { url in
                    guard url.scheme == "mamstudy" else { return }
                    switch url.host { case "schedule": store.tab = 1; case "focus": store.tab = 2; case "cards": store.tab = 3; case "notes": store.tab = 4; default: store.tab = 0 }
                }
                .alert("Mầm", isPresented: Binding(get: { store.errorMessage != nil }, set: { if !$0 { store.errorMessage = nil } })) {
                    Button("Đã hiểu", role: .cancel) { store.errorMessage = nil }
                } message: { Text(store.errorMessage ?? "") }
        }
    }
}

struct RootView: View {
    @EnvironmentObject private var store: AppStore
    var body: some View {
        TabView(selection: $store.tab) {
            TodayView().tabItem { Label("Hôm nay", systemImage: "sun.max") }.tag(0)
            PlannerView().tabItem { Label("Kế hoạch", systemImage: "calendar") }.tag(1)
            FocusView().tabItem { Label("Tập trung", systemImage: "leaf") }.tag(2)
            CardsView().tabItem { Label("Ôn thẻ", systemImage: "rectangle.on.rectangle") }.tag(3)
            NotebookView().tabItem { Label("Sổ tay", systemImage: "pencil.and.scribble") }.tag(4)
        }
        .fullScreenCover(isPresented: Binding(get: { !store.state.preferences.hasOnboarded && !store.readOnly }, set: { _ in })) {
            WelcomeView()
        }
    }
}

private struct WelcomeView: View {
    @EnvironmentObject private var store: AppStore
    @State private var name = ""
    @State private var goal = 60
    var body: some View {
        NavigationStack {
            PaperPage {
                Text("Mầm").font(.system(size: 56, weight: .bold, design: .serif))
                Text("Mỗi ngày, lớn thêm một chút.").font(.title3)
                Sprout()
                PaperCard(color: .butter) {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Một cuốn sổ nhỏ cho việc học").font(.headline)
                        Label("Lịch ở trường, tự học và bài tập", systemImage: "calendar")
                        Label("Trồng mầm bằng từng phiên tập trung", systemImage: "leaf")
                        Label("Ôn điều cần nhớ, đúng lúc", systemImage: "rectangle.on.rectangle")
                    }
                }
                TextField("Bạn muốn Mầm gọi mình là gì?", text: $name).textFieldStyle(.roundedBorder)
                Stepper("Mục tiêu: \(goal) phút / ngày", value: $goal, in: 15...180, step: 15)
                Text("Không cần tài khoản. Dữ liệu lưu trên iPhone. Bạn chủ động bật quyền báo thức và thông báo khi cần.")
                    .font(.footnote).foregroundStyle(.secondary)
                Button("Mở sổ của mình") {
                    _ = store.change { $0.preferences.name = name.trimmed.isEmpty ? "Bạn" : name.trimmed; $0.preferences.dailyFocusMinutes = goal; $0.preferences.hasOnboarded = true }
                }.buttonStyle(PencilButtonStyle())
            }
        }
    }
}
