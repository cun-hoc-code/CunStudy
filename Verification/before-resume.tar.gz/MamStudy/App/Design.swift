import SwiftUI

extension InkColor {
    var wash: Color {
        switch self {
        case .sage: return Color(red: 0.80, green: 0.88, blue: 0.75)
        case .peach: return Color(red: 0.98, green: 0.82, blue: 0.66)
        case .lavender: return Color(red: 0.86, green: 0.82, blue: 0.94)
        case .sky: return Color(red: 0.77, green: 0.87, blue: 0.94)
        case .butter: return Color(red: 0.98, green: 0.93, blue: 0.68)
        case .rose: return Color(red: 0.96, green: 0.80, blue: 0.80)
        }
    }
}

enum Pencil {
    static let ink = Color(red: 0.21, green: 0.25, blue: 0.20)
    static let paper = Color(red: 0.985, green: 0.974, blue: 0.944)
    static let green = Color(red: 0.26, green: 0.39, blue: 0.24)
    static let weekdays = [2, 3, 4, 5, 6, 7, 1]
    static func weekday(_ value: Int) -> String { value == 1 ? "CN" : "T\(value)" }
    static func time(_ minute: Int) -> String { String(format: "%02d:%02d", (minute / 60) % 24, minute % 60) }
    static func duration(_ minutes: Double) -> String {
        let n = max(0, Int(minutes)); return n >= 60 ? "\(n / 60) giờ \(n % 60) phút" : "\(n) phút"
    }
}

struct PencilOutline: Shape {
    func path(in r: CGRect) -> Path {
        Path { p in
            p.move(to: CGPoint(x: 17, y: 2))
            p.addQuadCurve(to: CGPoint(x: r.width - 18, y: 3), control: CGPoint(x: r.midX, y: -1))
            p.addQuadCurve(to: CGPoint(x: r.width - 2, y: 19), control: CGPoint(x: r.width, y: 2))
            p.addLine(to: CGPoint(x: r.width - 3, y: r.height - 19))
            p.addQuadCurve(to: CGPoint(x: r.width - 19, y: r.height - 3), control: CGPoint(x: r.width, y: r.height))
            p.addQuadCurve(to: CGPoint(x: 19, y: r.height - 2), control: CGPoint(x: r.midX, y: r.height + 1))
            p.addQuadCurve(to: CGPoint(x: 3, y: r.height - 18), control: CGPoint(x: 0, y: r.height))
            p.addLine(to: CGPoint(x: 2, y: 19))
            p.addQuadCurve(to: CGPoint(x: 17, y: 2), control: .zero)
            p.closeSubpath()
        }
    }
}

struct PaperBackground: View {
    var body: some View {
        Pencil.paper.overlay {
            Canvas { context, size in
                for y in stride(from: 16.0, to: size.height, by: 24) {
                    for x in stride(from: 16.0, to: size.width, by: 24) {
                        context.fill(Path(ellipseIn: CGRect(x: x, y: y, width: 1.3, height: 1.3)), with: .color(Pencil.ink.opacity(0.08)))
                    }
                }
            }.accessibilityHidden(true)
        }.ignoresSafeArea()
    }
}

struct PaperCard<Content: View>: View {
    var color: InkColor? = nil
    @ViewBuilder var content: () -> Content
    var body: some View {
        content().frame(maxWidth: .infinity, alignment: .leading).padding(17)
            .background(PencilOutline().fill(color?.wash ?? .white.opacity(0.88)))
            .overlay(PencilOutline().stroke(Pencil.ink.opacity(0.28), style: StrokeStyle(lineWidth: 1.3, lineCap: .round, lineJoin: .round)))
    }
}

struct PaperPage<Content: View>: View {
    @ViewBuilder var content: () -> Content
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18, content: content)
                .frame(maxWidth: 720).padding(20).frame(maxWidth: .infinity)
        }.background(PaperBackground())
    }
}

struct PencilButtonStyle: ButtonStyle {
    var color: InkColor = .sage
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.font(.system(.body, design: .rounded, weight: .semibold))
            .foregroundStyle(Pencil.ink).padding(.horizontal, 17).padding(.vertical, 13)
            .frame(maxWidth: .infinity).background(PencilOutline().fill(color.wash))
            .overlay(PencilOutline().stroke(Pencil.ink.opacity(0.35), lineWidth: 1.2))
            .opacity(configuration.isPressed ? 0.7 : 1)
    }
}

struct SectionTitle: View {
    let title: String
    var caption: String? = nil
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.system(.title3, design: .rounded, weight: .bold))
            if let caption { Text(caption).font(.footnote).foregroundStyle(.secondary) }
        }
    }
}

struct EmptyPageCard: View {
    let symbol: String
    let title: String
    let detail: String
    var body: some View {
        PaperCard {
            HStack(alignment: .top, spacing: 14) {
                Image(systemName: symbol).font(.title2).foregroundStyle(Pencil.green)
                VStack(alignment: .leading, spacing: 5) { Text(title).font(.headline); Text(detail).font(.subheadline).foregroundStyle(.secondary) }
            }
        }
    }
}

struct Chip: View {
    let text: String
    var color: InkColor = .sage
    var body: some View { Text(text).font(.caption.weight(.medium)).padding(.horizontal, 9).padding(.vertical, 5).background(color.wash, in: Capsule()) }
}

struct Sprout: View {
    var progress: Double = 1
    var body: some View {
        Canvas { context, size in
            let x = size.width / 2, bottom = size.height * 0.84
            let height = size.height * (0.22 + 0.40 * min(1, max(0, progress)))
            var ground = Path(); ground.move(to: CGPoint(x: x - 48, y: bottom)); ground.addQuadCurve(to: CGPoint(x: x + 48, y: bottom), control: CGPoint(x: x, y: bottom + 7))
            context.stroke(ground, with: .color(Pencil.ink.opacity(0.4)), style: StrokeStyle(lineWidth: 2, lineCap: .round))
            var stem = Path(); stem.move(to: CGPoint(x: x, y: bottom)); stem.addQuadCurve(to: CGPoint(x: x + 3, y: bottom - height), control: CGPoint(x: x - 10, y: bottom - height / 2))
            context.stroke(stem, with: .color(Pencil.green), style: StrokeStyle(lineWidth: 4, lineCap: .round))
            for side in [-1.0, 1.0] {
                let origin = CGPoint(x: x, y: bottom - height * 0.7)
                let tip = CGPoint(x: x + side * 53, y: bottom - height * 0.98)
                var leaf = Path(); leaf.move(to: origin)
                leaf.addQuadCurve(to: tip, control: CGPoint(x: x + side * 14, y: bottom - height - 28))
                leaf.addQuadCurve(to: origin, control: CGPoint(x: x + side * 45, y: bottom - height * 0.42))
                context.fill(leaf, with: .color(side < 0 ? InkColor.sage.wash : Pencil.green.opacity(0.55)))
                context.stroke(leaf, with: .color(Pencil.green), style: StrokeStyle(lineWidth: 1.6, lineCap: .round))
            }
        }.frame(height: 170).accessibilityLabel("Mầm cây, tiến độ \(Int(progress * 100)) phần trăm")
    }
}

struct ColorPickerRow: View {
    @Binding var selection: InkColor
    var body: some View {
        HStack {
            ForEach(InkColor.allCases) { color in
                Button { selection = color } label: {
                    Circle().fill(color.wash).frame(width: 35, height: 35)
                        .overlay { if selection == color { Image(systemName: "checkmark").foregroundStyle(Pencil.ink) } }
                }.buttonStyle(.plain).accessibilityLabel(color.title)
            }
        }
    }
}
