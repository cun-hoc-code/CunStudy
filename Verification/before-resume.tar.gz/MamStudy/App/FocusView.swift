import SwiftUI
import Charts

struct FocusView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var reminders: ReminderService
    @State private var subject = ""
    @State private var minutes = 25
    @State private var stopping = false
    @State private var showStats = false
    @State private var breakMessage = false
    var body: some View {
        NavigationStack {
            TimelineView(.periodic(from: .now, by: 1)) { context in
                PaperPage {
                    Text("Chỉ một việc, lúc này.").font(.system(.title, design: .rounded, weight: .bold))
                    Text("Đặt điện thoại xuống. Dành một khoảng nhỏ cho điều bạn muốn hiểu.").font(.subheadline).foregroundStyle(.secondary)
                    if let active = store.state.activeFocus {
                        activeContent(active, at: context.date)
                    } else {
                        setupContent
                    }
                    Button { showStats = true } label: { Label("Xem vườn & nhịp học", systemImage: "chart.bar.xaxis") }.buttonStyle(PencilButtonStyle(color: .butter))
                    Text("Đồng hồ tiếp tục khi bạn khóa máy hoặc rời app. Mầm không chặn các ứng dụng khác và không tự suy đoán bạn có đang chú ý hay không.").font(.caption).foregroundStyle(.secondary)
                }
                .onChange(of: context.date) { _, _ in store.settleFocus() }
            }
            .navigationTitle("Tập trung").navigationBarTitleDisplayMode(.inline)
            .onAppear { minutes = store.state.preferences.focusMinutes }
            .sheet(isPresented: $showStats) { FocusStatsView() }
            .confirmationDialog("Kết thúc phiên này?", isPresented: $stopping, titleVisibility: .visible) {
                Button("Lưu thời gian đã học") { store.finishFocus() }
                Button("Bỏ phiên này", role: .destructive) { store.finishFocus(discard: true) }
            }
            .alert("Đã bắt đầu giờ nghỉ", isPresented: $breakMessage) {
                Button("Được") {}
            } message: { Text("Bạn sẽ nhận thông báo sau \(store.state.preferences.breakMinutes) phút nếu đã cấp quyền thông báo.") }
        }
    }
    private var setupContent: some View {
        VStack(spacing: 18) {
            Sprout(progress: 0.25)
            PaperCard {
                VStack(alignment: .leading, spacing: 14) {
                    TextField("Môn học hoặc mục tiêu phiên này", text: $subject).textInputAutocapitalization(.sentences)
                    HStack {
                        ForEach([25, 45, 60], id: \.self) { n in
                            Button("\(n) phút") { minutes = n }.buttonStyle(PencilButtonStyle(color: minutes == n ? .sage : .sky))
                        }
                    }
                    Stepper("Tùy chỉnh: \(minutes) phút", value: $minutes, in: 5...120, step: 5)
                }
            }
            Button { store.startFocus(subject: subject, minutes: minutes) } label: { Label("Trồng một mầm mới", systemImage: "play.fill") }.buttonStyle(PencilButtonStyle())
            Button("Nghỉ \(store.state.preferences.breakMinutes) phút") {
                Task { await reminders.startBreak(minutes: store.state.preferences.breakMinutes); breakMessage = true }
            }.font(.subheadline)
        }
    }
    private func activeContent(_ active: ActiveFocus, at now: Date) -> some View {
        let left = max(0, Int(ceil(active.plannedSeconds - active.elapsed(at: now))))
        return VStack(spacing: 18) {
            Sprout(progress: active.elapsed(at: now) / active.plannedSeconds)
            Text(String(format: "%02d:%02d", left / 60, left % 60))
                .font(.system(size: 60, weight: .light, design: .rounded)).monospacedDigit()
                .accessibilityLabel("Còn \(left / 60) phút \(left % 60) giây")
            Text(active.subject).font(.headline)
            Text(active.isPaused ? "Đang tạm dừng • thời gian nghỉ không được tính" : "Mầm đang lớn cùng bạn").font(.subheadline).foregroundStyle(.secondary)
            ProgressView(value: active.elapsed(at: now), total: active.plannedSeconds).tint(Pencil.green)
            HStack {
                Button(active.isPaused ? "Tiếp tục" : "Tạm dừng") { store.pauseOrResume() }.buttonStyle(PencilButtonStyle())
                Button("Kết thúc") { stopping = true }.buttonStyle(PencilButtonStyle(color: .peach))
            }
        }
    }
}

private struct FocusStatsView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var range = 7
    var body: some View {
        NavigationStack {
            PaperPage {
                Picker("Thời gian", selection: $range) { Text("7 ngày").tag(7); Text("30 ngày").tag(30) }.pickerStyle(.segmented)
                let days = StudyStats.daily(store.state.sessions, ending: Date(), days: range)
                let sum = days.reduce(0) { $0 + $1.minutes }
                PaperCard(color: .sage) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(Pencil.duration(sum)).font(.system(.largeTitle, design: .rounded, weight: .bold))
                        Text("trong \(range) ngày • \(days.filter { $0.minutes > 0 }.count) ngày có học").font(.subheadline)
                    }
                }
                PaperCard {
                    Chart(Array(days.enumerated()), id: \.offset) { pair in
                        BarMark(x: .value("Ngày", pair.element.date, unit: .day), y: .value("Phút", pair.element.minutes))
                            .foregroundStyle(Pencil.green.gradient).cornerRadius(4)
                        RuleMark(y: .value("Mục tiêu", store.state.preferences.dailyFocusMinutes))
                            .foregroundStyle(.orange.opacity(0.5)).lineStyle(StrokeStyle(dash: [4]))
                    }.frame(height: 190).chartYAxisLabel("phút")
                }
                PaperCard(color: .butter) { Text(StudyStats.insight(store.state.sessions, at: Date())).font(.subheadline) }
                SectionTitle(title: "Mỗi phiên xong, một mầm", caption: "\(store.state.sessions.filter(\.completed).count) phiên hoàn thành từ trước đến nay")
                LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 7), spacing: 14) {
                    ForEach(store.state.sessions.filter(\.completed).suffix(35)) { session in
                        Image(systemName: "leaf.fill").font(.title2).foregroundStyle(Pencil.green.opacity(0.75))
                            .accessibilityLabel("\(session.subject), \(Int(session.seconds / 60)) phút")
                    }
                }
                SectionTitle(title: "Theo môn trong \(range) ngày")
                let subjects = Set(store.state.sessions.map(\.subject)).sorted()
                ForEach(subjects, id: \.self) { subject in
                    let seconds = StudyStats.seconds(store.state.sessions.filter { $0.subject == subject },
                        from: days.first?.date ?? Date(), to: Date())
                    if seconds > 0 {
                        HStack { Text(subject); Spacer(); Text(Pencil.duration(seconds / 60)).foregroundStyle(.secondary) }.font(.subheadline)
                    }
                }
                SectionTitle(title: "Các phiên gần đây")
                ForEach(store.state.sessions.sorted { $0.finishedAt > $1.finishedAt }.prefix(12)) { session in
                    HStack {
                        VStack(alignment: .leading) { Text(session.subject); Text(session.finishedAt, format: .dateTime.day().month().hour().minute()).font(.caption).foregroundStyle(.secondary) }
                        Spacer(); Text(Pencil.duration(session.seconds / 60)).font(.subheadline)
                        Image(systemName: session.completed ? "checkmark.seal" : "circle.lefthalf.filled").foregroundStyle(Pencil.green)
                    }
                }
            }
            .navigationTitle("Vườn & nhịp học").navigationBarTitleDisplayMode(.inline)
            .toolbar { Button("Xong") { dismiss() } }
        }
    }
}
