import SwiftUI
import UniformTypeIdentifiers
import UIKit

struct SettingsView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var reminders: ReminderService
    @Environment(\.dismiss) private var dismiss
    @State private var preferences = Preferences()
    @State private var shareURL: URL?
    @State private var importing = false
    @State private var pendingImport: StudyState?
    @State private var restoreConfirm = false
    @State private var previousConfirm = false
    @State private var message: String?
    var body: some View {
        NavigationStack {
            Form {
                Section("Nhịp học của mình") {
                    TextField("Tên gọi", text: $preferences.name)
                    Stepper("Tập trung: \(preferences.dailyFocusMinutes) phút / ngày", value: $preferences.dailyFocusMinutes, in: 15...240, step: 15)
                    Stepper("Phiên mặc định: \(preferences.focusMinutes) phút", value: $preferences.focusMinutes, in: 5...120, step: 5)
                    Stepper("Giờ nghỉ: \(preferences.breakMinutes) phút", value: $preferences.breakMinutes, in: 1...30)
                    Stepper("Thẻ mới: \(preferences.newCardsPerDay) / ngày", value: $preferences.newCardsPerDay, in: 1...100)
                    Button("Lưu thiết lập") { if store.change({ $0.preferences = preferences }) { message = "Đã lưu thiết lập." } }
                }
                Section {
                    LabeledContent("Báo thức", value: reminders.alarmPermission)
                    Button("Cho phép báo thức hệ thống") { Task { await reminders.requestAlarms(); store.refresh() } }
                    Button("Thử báo thức sau 30 giây") { Task { await reminders.testAlarm() } }
                    LabeledContent("Thông báo", value: reminders.notificationPermission)
                    Button("Cho phép thông báo") { Task { await reminders.requestNotifications(); store.refresh() } }
                    Button("Mở cài đặt iPhone") {
                        if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) }
                    }
                    Text(reminders.status).font(.footnote)
                    ForEach(reminders.problems, id: \.self) { Text($0).font(.footnote).foregroundStyle(.red) }
                } header: { Text("Nhắc đi học") } footer: {
                    Text("Báo thức thật dùng AlarmKit trên iOS 26+, cần bạn cấp quyền. Hãy thử khi khóa màn hình và tắt app trước buổi học đầu tiên. Máy hết pin hoặc tắt nguồn không thể phát báo thức từ app. Thông báo thường không thay thế báo thức.")
                }
                Section {
                    Text(store.widgetMessage).font(.subheadline)
                    Button("Gửi lại dữ liệu cho widget") { store.publishSnapshot() }
                    Text("Nhấn giữ màn hình chính → Sửa → Thêm tiện ích → Mầm. Chọn Lịch tiếp theo hoặc Nhịp học.").font(.footnote)
                } header: { Text("Widget màn hình chính") } footer: {
                    Text("Sau mỗi lần lưu lịch, Mầm gửi dữ liệu mới và yêu cầu iOS cập nhật widget. iOS có thể trì hoãn thời điểm vẽ lại. Bản ký phải giữ widget extension và quyền App Groups phù hợp.")
                }
                Section {
                    Button("Xuất bản sao lưu JSON") {
                        do { shareURL = try store.exportData() } catch { message = error.localizedDescription }
                    }
                    Button("Nhập bản sao lưu") { importing = true }
                    Button("Khôi phục bản lưu trước đó") { previousConfirm = true }
                    if store.state.lessons.isEmpty && store.state.tasks.isEmpty && store.state.cards.isEmpty && store.state.notes.isEmpty {
                        Button("Thử dữ liệu mẫu") { store.addDemo() }
                    }
                } header: { Text("Dữ liệu của bạn") } footer: {
                    Text("Lưu file sao lưu vào ứng dụng Tệp hoặc iCloud Drive tùy bạn chọn. Mầm chưa có đồng bộ iCloud tự động. App mới có dữ liệu độc lập với StudyFlow cũ.")
                }
                Section("Về Mầm") {
                    Text("Phiên bản 1.0 • Sổ học tập cá nhân")
                    Text("Không quảng cáo, không tài khoản, không dịch vụ phân tích gửi ra ngoài.").font(.footnote)
                    Text("Ôn tập dùng thuật toán giãn cách lấy cảm hứng từ SM-2 với bước học ngắn. Không phải FSRS của Anki và không có bảo đảm nhớ nhanh hơn cho mọi người.").font(.footnote)
                    Text("Giao diện nền giấy sáng được chọn để giữ độ tương phản của bảng màu bút chì.").font(.footnote)
                }
            }
            .navigationTitle("Cài đặt").navigationBarTitleDisplayMode(.inline)
            .toolbar { Button("Xong") { dismiss() } }
            .onAppear { preferences = store.state.preferences; Task { await reminders.updatePermissionLabels() } }
            .sheet(isPresented: Binding(get: { shareURL != nil }, set: { if !$0 { shareURL = nil } })) { if let shareURL { ActivityShare(url: shareURL) } }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.json]) { result in
                do { pendingImport = try store.readImport(result.get()); restoreConfirm = true }
                catch { message = error.localizedDescription }
            }
            .confirmationDialog("Thay dữ liệu hiện tại bằng bản sao lưu?", isPresented: $restoreConfirm, titleVisibility: .visible) {
                Button("Khôi phục dữ liệu", role: .destructive) { if let pendingImport { store.restore(pendingImport); preferences = store.state.preferences }; pendingImport = nil }
                Button("Hủy", role: .cancel) { pendingImport = nil }
            } message: { Text("Bản dữ liệu hiện tại được giữ thành file phục hồi trước khi thay thế. Phiên tập trung nhập vào sẽ ở trạng thái tạm dừng.") }
            .confirmationDialog("Khôi phục bản lưu trước lần thay đổi gần nhất?", isPresented: $previousConfirm, titleVisibility: .visible) {
                Button("Khôi phục", role: .destructive) { store.restorePrevious(); preferences = store.state.preferences }
            }
            .alert("Mầm", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) { Button("OK") { message = nil } } message: { Text(message ?? "") }
        }
    }
}

private struct ActivityShare: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: [url], applicationActivities: nil) }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
