import SwiftUI
import Combine
import WidgetKit

@MainActor
final class AppStore: ObservableObject {
    @Published private(set) var state = StudyState()
    @Published var errorMessage: String?
    @Published var widgetMessage = "Chưa kiểm tra"
    @Published private(set) var readOnly = false
    @Published var tab = 0
    @Published var reviewUndoAvailable = false
    let reminders = ReminderService()
    private let disk: DiskStore
    private var previousReview: (Flashcard, UUID)?

    init() {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        disk = DiskStore(directory: base.appendingPathComponent("MamStudy", isDirectory: true))
        do { state = try disk.load() } catch {
            readOnly = true
            errorMessage = "Không đọc được dữ liệu đã lưu. Dữ liệu gốc được giữ nguyên. Vào Cài đặt để khôi phục bản trước hoặc nhập bản sao lưu. \(error.localizedDescription)"
        }
        refresh()
    }

    @discardableResult
    func change(_ edit: (inout StudyState) -> Void) -> Bool {
        guard !readOnly else { errorMessage = "Hãy khôi phục dữ liệu trong Cài đặt trước khi sửa."; return false }
        var next = state; edit(&next)
        do {
            try StateCodec.validate(next)
            try disk.save(next)
            state = next
            publishSnapshot()
            reminders.reconcile(state)
            return true
        } catch { errorMessage = "Chưa lưu được: \(error.localizedDescription)"; return false }
    }

    func refresh() {
        guard !readOnly else { return }
        settleFocus()
        publishSnapshot()
        reminders.reconcile(state)
    }
    func publishSnapshot() {
        let today = StudyStats.daily(state.sessions, ending: Date(), days: 1).first?.minutes ?? 0
        let value = WidgetSnapshot(updatedAt: Date(), lessons: state.lessons,
            pendingTasks: state.tasks.filter { !$0.done }.count,
            dueCards: ReviewEngine.queue(state, at: Date()).count,
            todayFocusMinutes: Int(today), goalMinutes: state.preferences.dailyFocusMinutes)
        do { try WidgetStorage.save(value); WidgetCenter.shared.reloadAllTimelines(); widgetMessage = "Đã gửi dữ liệu mới tới widget." }
        catch { widgetMessage = error.localizedDescription }
    }
    func saveLesson(_ value: Lesson) -> Bool { change { upsert(value, in: &$0.lessons) } }
    func saveTask(_ value: StudyTask) -> Bool { change { upsert(value, in: &$0.tasks) } }
    func saveNote(_ value: QuickNote) -> Bool { change { upsert(value, in: &$0.notes) } }
    func saveCard(_ value: Flashcard) -> Bool { change { upsert(value, in: &$0.cards) } }
    func toggleTask(_ id: UUID) {
        _ = change { s in
            guard let i = s.tasks.firstIndex(where: { $0.id == id }) else { return }
            s.tasks[i].done.toggle(); s.tasks[i].completedAt = s.tasks[i].done ? Date() : nil
        }
    }
    func startFocus(subject: String, minutes: Int) {
        guard state.activeFocus == nil else { return }
        let now = Date()
        _ = change { $0.activeFocus = ActiveFocus(subject: subject.trimmed.isEmpty ? "Tự học" : subject.trimmed,
                plannedSeconds: Double(minutes * 60), startedAt: now, runningSince: now) }
    }
    func pauseOrResume() {
        settleFocus()
        _ = change { s in
            if s.activeFocus?.isPaused == true { s.activeFocus?.resume(at: Date()) }
            else { s.activeFocus?.pause(at: Date()) }
        }
    }
    func finishFocus(discard: Bool = false) {
        guard let active = state.activeFocus else { return }
        _ = change { s in
            let session = active.finish(at: Date())
            if !discard && session.seconds >= 1 && !s.sessions.contains(where: { $0.id == session.id }) { s.sessions.append(session) }
            s.activeFocus = nil
        }
    }
    func settleFocus() {
        guard let active = state.activeFocus, let end = active.endDate, end <= Date() else { return }
        finishFocus()
    }
    func review(_ card: Flashcard, rating: RecallRating) {
        guard let current = state.cards.first(where: { $0.id == card.id }) else { return }
        let now = Date()
        let log = ReviewLog(cardID: card.id, date: now, rating: rating, wasNew: current.isNew)
        if change({ s in upsert(ReviewEngine.graded(current, rating: rating, at: now), in: &s.cards); s.reviews.append(log) }) {
            previousReview = (current, log.id); reviewUndoAvailable = true
        }
    }
    func undoReview() {
        guard let (card, logID) = previousReview else { return }
        if change({ upsert(card, in: &$0.cards); $0.reviews.removeAll { $0.id == logID } }) {
            previousReview = nil; reviewUndoAvailable = false
        }
    }
    func exportData() throws -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("MamStudy-backup.json")
        try StateCodec.encode(state).write(to: url, options: .atomic)
        return url
    }
    func readImport(_ url: URL) throws -> StudyState {
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        let values = try url.resourceValues(forKeys: [.fileSizeKey])
        guard (values.fileSize ?? 0) <= 25 * 1024 * 1024 else { throw StudyError.invalid("File lớn hơn 25 MB.") }
        var value = try StateCodec.decode(Data(contentsOf: url))
        // Importing a backup must not create hours of accidental focus time.
        if var active = value.activeFocus {
            active.runningSince = nil
            value.activeFocus = active
        }
        return value
    }
    func restore(_ value: StudyState) {
        do {
            try StateCodec.validate(value)
            try FileManager.default.createDirectory(at: disk.directory, withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: disk.file.path) {
                let backup = disk.directory.appendingPathComponent("before-restore-\(UUID().uuidString).json")
                try FileManager.default.copyItem(at: disk.file, to: backup)
            }
            try StateCodec.encode(value).write(to: disk.file, options: .atomic)
            state = value; readOnly = false; previousReview = nil; reviewUndoAvailable = false
            refresh()
        } catch { errorMessage = "Chưa khôi phục: \(error.localizedDescription)" }
    }
    func restorePrevious() {
        do { restore(try StateCodec.decode(Data(contentsOf: disk.previous))) }
        catch { errorMessage = "Không đọc được bản trước: \(error.localizedDescription)" }
    }
    func addDemo() {
        _ = change { s in
            guard s.lessons.isEmpty && s.tasks.isEmpty && s.cards.isEmpty && s.notes.isEmpty else { return }
            var lesson = Lesson(); lesson.title = "Lập trình hướng đối tượng"; lesson.subject = "C++ / OOP"
            lesson.weekdays = [2, 5]; lesson.location = "Phòng học mẫu"; lesson.color = .sage
            var home = Lesson(); home.title = "Ôn tiếng Anh"; home.area = .home; home.weekdays = [2, 4, 6]
            home.startMinute = 19 * 60; home.durationMinutes = 45; home.color = .lavender
            var task = StudyTask(); task.title = "Thử tạo lịch học của mình"; task.area = .personal
            var note = QuickNote(); note.title = "Chào bạn, đây là Mầm 🌱"; note.body = "Dữ liệu này là ví dụ. Bạn có thể sửa hoặc xóa để bắt đầu sổ học tập riêng."
            var card = Flashcard(); card.deck = "Tiếng Anh"; card.kind = .vocabulary; card.front = "curious"; card.back = "tò mò, ham tìm hiểu"; card.example = "I am curious about how this works."
            s.lessons = [lesson, home]; s.tasks = [task]; s.notes = [note]; s.cards = [card]
        }
    }
}

private func upsert<T: Identifiable>(_ value: T, in array: inout [T]) where T.ID: Equatable {
    if let i = array.firstIndex(where: { $0.id == value.id }) { array[i] = value } else { array.append(value) }
}
extension String { var trimmed: String { trimmingCharacters(in: .whitespacesAndNewlines) } }
