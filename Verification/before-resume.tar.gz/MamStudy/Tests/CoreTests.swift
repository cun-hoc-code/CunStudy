import XCTest
@testable import StudyCore

final class CoreTests: XCTestCase {
    let utc = ScheduleEngine.calendar(TimeZone(secondsFromGMT: 0)!)
    func date(_ s: String) -> Date { ISO8601DateFormatter().date(from: s)! }

    func testWeeklyAlarmCanMoveToPreviousDayAndWeek() {
        let v = ScheduleEngine.shifted(weekday: 2, minute: 10, lead: 40)
        XCTAssertEqual(v.weekday, 1); XCTAssertEqual(v.minute, 23 * 60 + 30)
        let sunday = ScheduleEngine.shifted(weekday: 1, minute: 0, lead: 60)
        XCTAssertEqual(sunday.weekday, 7); XCTAssertEqual(sunday.minute, 1380)
    }
    func testWeekdaysOneOffAndDisabledSchedules() {
        var l = Lesson(); l.title = "OOP"; l.weekdays = [2, 4]
        let start = date("2026-09-14T00:00:00Z")
        XCTAssertEqual(ScheduleEngine.occurrences([l], from: start, days: 7, calendar: utc).count, 2)
        l.weekly = false; l.date = start
        XCTAssertEqual(ScheduleEngine.occurrences([l], from: start, days: 14, calendar: utc).count, 1)
        l.enabled = false
        XCTAssertTrue(ScheduleEngine.occurrences([l], from: start, calendar: utc).isEmpty)
    }
    func testLateNightLessonRemainsVisibleAfterMidnight() {
        var l = Lesson(); l.title = "Ôn thi"; l.weekdays = [2]; l.startMinute = 23 * 60 + 30; l.durationMinutes = 90
        let now = date("2026-09-15T00:15:00Z")
        let next = ScheduleEngine.next([l], at: now, calendar: utc)
        XCTAssertEqual(next?.start, date("2026-09-14T23:30:00Z"))
        XCTAssertEqual(ScheduleEngine.occurrences([l], from: now, days: 1, calendar: utc).count, 1)
    }
    func testWeeklyTimeKeepsLocalHourAcrossDST() {
        let cal = ScheduleEngine.calendar(TimeZone(identifier: "America/New_York")!)
        var l = Lesson(); l.title = "Học"; l.weekdays = [1]; l.startMinute = 7 * 60
        let values = ScheduleEngine.occurrences([l], from: date("2026-03-01T12:00:00Z"), days: 9, calendar: cal)
        XCTAssertEqual(values.count, 2)
        XCTAssertTrue(values.allSatisfy { cal.component(.hour, from: $0.start) == 7 })
        XCTAssertEqual(values[1].start.timeIntervalSince(values[0].start), 7 * 86400 - 3600)
    }
    func testOneOffAlarmAndNoDoubleCountingAtTouchingEdges() {
        var l = Lesson(); l.title = "Thi"; l.weekly = false
        l.date = date("2026-09-14T00:00:00Z"); l.startMinute = 10; l.leadMinutes = 40
        XCTAssertEqual(ScheduleEngine.oneOffFire(l, calendar: utc), date("2026-09-13T23:30:00Z"))
        let a = LessonOccurrence(lesson: l, start: l.date, end: l.date.addingTimeInterval(60))
        let b = LessonOccurrence(lesson: l, start: a.end, end: a.end.addingTimeInterval(60))
        XCTAssertFalse(ScheduleEngine.overlaps(a, b))
    }
    func testTimerSurvivesClosingAndCapsAtPlannedDuration() {
        let start = date("2026-09-14T07:00:00Z")
        let f = ActiveFocus(subject: "OOP", plannedSeconds: 1500, startedAt: start, runningSince: start)
        let session = f.finish(at: start.addingTimeInterval(10000))
        XCTAssertEqual(session.seconds, 1500)
        XCTAssertEqual(session.finishedAt, start.addingTimeInterval(1500))
        XCTAssertTrue(session.completed)
    }
    func testPausedTimeNeverCounts() {
        let start = date("2026-09-14T07:00:00Z")
        var f = ActiveFocus(subject: "OOP", plannedSeconds: 1500, startedAt: start, runningSince: start)
        f.pause(at: start.addingTimeInterval(300))
        XCTAssertEqual(f.elapsed(at: start.addingTimeInterval(900)), 300)
        f.resume(at: start.addingTimeInterval(900))
        XCTAssertEqual(f.finish(at: start.addingTimeInterval(1200)).seconds, 600)
    }
    func testStatsSplitAcrossMidnight() {
        let start = date("2026-09-14T23:50:00Z")
        let session = ActiveFocus(subject: "OOP", plannedSeconds: 1200, startedAt: start, runningSince: start).finish(at: start.addingTimeInterval(1200))
        let days = StudyStats.daily([session], ending: date("2026-09-15T12:00:00Z"), days: 2, calendar: utc)
        XCTAssertEqual(days[0].minutes, 10); XCTAssertEqual(days[1].minutes, 10)
    }
    func testForgottenCardReturnsSoonAndLearningGraduates() {
        let now = date("2026-09-14T12:00:00Z")
        var card = Flashcard(); card.front = "A"; card.back = "B"
        card = ReviewEngine.graded(card, rating: .good, at: now)
        XCTAssertEqual(card.due.timeIntervalSince(now), 600)
        card = ReviewEngine.graded(card, rating: .good, at: card.due)
        XCTAssertEqual(card.intervalDays, 1)
        card = ReviewEngine.graded(card, rating: .again, at: now)
        XCTAssertEqual(card.due.timeIntervalSince(now), 60)
        XCTAssertEqual(card.lapses, 1); XCTAssertEqual(card.intervalDays, 0)
    }
    func testOverdueReviewsPrecedeNewCardsAndNewLimitPersists() {
        let now = Date(); var state = StudyState(); state.preferences.newCardsPerDay = 1
        var old = Flashcard(); old.reviews = 5; old.due = now.addingTimeInterval(-60)
        let firstNew = Flashcard(); state.cards = [firstNew, Flashcard(), old]
        XCTAssertEqual(ReviewEngine.queue(state, at: now).map(\.id), [old.id, firstNew.id])
        state.reviews.append(.init(cardID: firstNew.id, date: now, rating: .good, wasNew: true))
        XCTAssertEqual(ReviewEngine.queue(state, at: now).map(\.id), [old.id])
    }
    func testClozeAndSuspension() {
        var c = Flashcard(); c.kind = .cloze; c.front = "C++ có {{kế thừa}} và {{đa hình}}."
        XCTAssertEqual(c.question, "C++ có […] và […].")
        XCTAssertEqual(c.answer, "C++ có kế thừa và đa hình.")
        c.suspended = true; var state = StudyState(); state.cards = [c]
        XCTAssertTrue(ReviewEngine.queue(state, at: Date()).isEmpty)
    }
    func testTSVImportIsAtomicOnMalformedRow() throws {
        XCTAssertEqual(try ReviewEngine.importTSV("front\tback\nhello\txin chào", deck: "EN").count, 1)
        XCTAssertThrowsError(try ReviewEngine.importTSV("hello\txin chào\nbroken", deck: "EN"))
    }
    func testBackupRejectsUnsupportedVersionAndInvalidTime() throws {
        var state = StudyState(); state.schemaVersion = 10
        XCTAssertThrowsError(try StateCodec.decode(StateCodec.encode(state)))
        state.schemaVersion = 1; var l = Lesson(); l.title = "OOP"; l.startMinute = 2000; state.lessons = [l]
        XCTAssertThrowsError(try StateCodec.decode(StateCodec.encode(state)))
    }
    func testDiskRoundTripAndKeepsPreviousVersion() throws {
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: dir) }
        let disk = DiskStore(directory: dir); var state = StudyState()
        try disk.save(state); state.preferences.name = "Cún"; try disk.save(state)
        XCTAssertEqual(try disk.load().preferences.name, "Cún")
        XCTAssertEqual(try StateCodec.decode(Data(contentsOf: disk.previous)).preferences.name, "Bạn")
        try Data("corrupt".utf8).write(to: disk.file)
        XCTAssertThrowsError(try disk.save(state))
        XCTAssertEqual(try StateCodec.decode(Data(contentsOf: disk.previous)).preferences.name, "Bạn")
    }
}
